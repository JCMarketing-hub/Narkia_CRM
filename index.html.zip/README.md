# Narquia Digital CRM

CRM mobile-first para prospecção de landing pages. Interface em grafite `#171321`, branco `#F8F7FC`, roxo `#7C3AED`, laranja `#FF6B1A`, tipografia system/Inter-inspired e ícone próprio.

## Funcionalidades
- Cadastro/edição/exclusão de leads
- Etapas de funil comercial
- Follow-ups e conclusão de retornos
- Dashboard e meta mensal
- Exportação CSV
- Layout responsivo para celular
- PWA básico com manifest e service worker para hospedagem HTTPS

## Publicar no GitHub Pages (pelo celular ou computador)
1. Entre em https://github.com e faça login.
2. Crie um repositório chamado `narquia-crm` (pode ser público).
3. Faça upload dos arquivos mantendo a estrutura:
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `assets/narquia-icon.svg`
4. Clique em **Commit changes**.
5. No repositório, abra **Settings → Pages**.
6. Em **Build and deployment**, selecione **Deploy from a branch**.
7. Escolha a branch `main` e a pasta `/(root)`, depois clique **Save**.
8. Aguarde a publicação e abra o endereço mostrado na área Pages, geralmente `https://SEU-USUARIO.github.io/narquia-crm/`.
9. No Android, abra o endereço no Chrome, menu ⋮ e escolha **Adicionar à tela inicial** ou **Instalar app** se essa opção aparecer.

## Atualizar o CRM
Edite os arquivos no GitHub e faça commit. O Pages publica as alterações automaticamente; pode levar alguns minutos. Se o app ficar com versão antiga, feche/reabra ou limpe o cache do site.

## Importante sobre dados e privacidade
- Leads são guardados no `localStorage` do navegador desse aparelho/perfil. Não existe banco de dados, conta de usuário, criptografia de aplicação nem sincronização entre dispositivos.
- Limpar os dados do navegador pode apagar os leads. Exporte o CSV regularmente.
- GitHub Pages hospeda conteúdo estático público. Não publique dados de clientes no repositório.
- O service worker melhora o acesso offline após a primeira visita, mas não substitui backup.
- Os leads de exemplo são fictícios; remova-os antes de usar em produção.
